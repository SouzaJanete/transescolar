package com.example.transescolar.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class TurnoTest {

    @Test
    void getId() {
    }

    @Test
    void setId() {
    }

    @Test
    void getNome() {
    }

    @Test
    void setNome() {
    }
}