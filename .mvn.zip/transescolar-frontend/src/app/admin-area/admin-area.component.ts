import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-area',
  standalone: true,
  imports: [],
  templateUrl: './admin-area.component.html',
  styleUrl: './admin-area.component.css'
})
export class AdminAreaComponent {

}
