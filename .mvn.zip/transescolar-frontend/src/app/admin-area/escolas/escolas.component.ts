import { Component } from '@angular/core';

@Component({
  selector: 'app-escolas',
  standalone: true,
  imports: [],
  templateUrl: './escolas.component.html',
  styleUrl: './escolas.component.css'
})
export class EscolasComponent {

}
